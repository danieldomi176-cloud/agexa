param([ValidateSet('Procurar','Instalar')][string]$Acao = 'Procurar')
$ErrorActionPreference = 'Stop'

function Test-PrivateIPv4([System.Net.IPAddress]$Address) {
    if ($Address.AddressFamily -ne [System.Net.Sockets.AddressFamily]::InterNetwork) { return $false }
    $b = $Address.GetAddressBytes()
    return ($b[0] -eq 10 -or ($b[0] -eq 172 -and $b[1] -ge 16 -and $b[1] -le 31) -or
        ($b[0] -eq 192 -and $b[1] -eq 168) -or ($b[0] -eq 169 -and $b[1] -eq 254))
}

function Find-LocalDevices {
    Write-Host 'A procurar dispositivos anunciados no seu Wi-Fi (SSDP, apenas leitura)...'
    $udp = New-Object System.Net.Sockets.UdpClient
    $found = @{}
    try {
        $udp.Client.ReceiveTimeout = 400
        $udp.Client.SetSocketOption([System.Net.Sockets.SocketOptionLevel]::IP,
            [System.Net.Sockets.SocketOptionName]::MulticastTimeToLive, 1)
        $query = "M-SEARCH * HTTP/1.1`r`nHOST: 239.255.255.250:1900`r`nMAN: `"ssdp:discover`"`r`nMX: 2`r`nST: ssdp:all`r`n`r`n"
        $bytes = [System.Text.Encoding]::ASCII.GetBytes($query)
        [void]$udp.Send($bytes, $bytes.Length, '239.255.255.250', 1900)
        $until = [DateTime]::UtcNow.AddSeconds(5)
        while ([DateTime]::UtcNow -lt $until) {
            $peer = [System.Net.IPEndPoint]::new([System.Net.IPAddress]::Any, 0)
            try { $reply = $udp.Receive([ref]$peer) }
            catch [System.Net.Sockets.SocketException] {
                if ($_.Exception.SocketErrorCode -eq [System.Net.Sockets.SocketError]::TimedOut) { continue }
                throw
            }
            if (-not (Test-PrivateIPv4 $peer.Address)) { continue }
            $headers = @{}
            foreach ($line in ([System.Text.Encoding]::UTF8.GetString($reply) -split "`r?`n")) {
                if ($line -match '^([^:]+):\s*(.*)$') { $headers[$Matches[1].Trim()] = $Matches[2].Trim() }
            }
            $ip = $peer.Address.ToString()
            if (-not $found.ContainsKey($ip) -or (-not $found[$ip].ContainsKey('LOCATION') -and $headers.ContainsKey('LOCATION'))) {
                $found[$ip] = $headers
            }
        }
    } finally { $udp.Dispose() }
    if ($found.Count -eq 0) {
        Write-Host 'Nenhum anuncio recebido. Isto nao prova que a TV esteja desligada.'
        Write-Host 'Veja o IP na TV em Definicoes > Rede. O ultimo IP informado foi 192.168.1.253.'
        return
    }
    Write-Host "`nDispositivos encontrados (a lista pode incluir aparelhos que nao sao TVs):"
    foreach ($ip in ($found.Keys | Sort-Object | Select-Object -First 20)) {
        $name = 'Dispositivo UPnP'; $model = ''
        try {
            $uri = [Uri]$found[$ip]['LOCATION']
            # Follow only descriptions hosted on the private device that answered; never follow redirects.
            if ($uri.Scheme -eq 'http' -and $uri.Host -eq $ip -and -not $uri.UserInfo) {
                $response = Invoke-WebRequest -Uri $uri -UseBasicParsing -TimeoutSec 2 -MaximumRedirection 0
                $settings = New-Object System.Xml.XmlReaderSettings
                $settings.DtdProcessing = [System.Xml.DtdProcessing]::Prohibit
                $settings.XmlResolver = $null
                $settings.MaxCharactersInDocument = 1048576
                $reader = [System.Xml.XmlReader]::Create([System.IO.StringReader]::new([string]$response.Content), $settings)
                try {
                    $doc = New-Object System.Xml.XmlDocument
                    $doc.XmlResolver = $null
                    $doc.Load($reader)
                    $device = $doc.SelectSingleNode("//*[local-name()='device']")
                    if ($device) {
                        $n = $device.SelectSingleNode("*[local-name()='friendlyName']")
                        $m = $device.SelectSingleNode("*[local-name()='modelName']")
                        if ($n) { $name = $n.InnerText }
                        if ($m) { $model = $m.InnerText }
                    }
                } finally { $reader.Dispose() }
            }
        } catch { }
        $name = $name -replace '[\x00-\x1f\x7f]', ''
        $model = $model -replace '[\x00-\x1f\x7f]', ''
        Write-Host ("{0} | {1} | {2}" -f $ip, $name, $model)
    }
    Write-Host "`nEsta procura nao instala nem altera nada nas TVs."
}

function Install-FreeMyTV {
    $adb = Join-Path $PSScriptRoot 'platform-tools\adb.exe'
    $apk = Join-Path $PSScriptRoot 'FreeMyTV.apk'
    if (-not (Test-Path -LiteralPath $adb) -or -not (Test-Path -LiteralPath $apk)) {
        throw 'Extraia todo o ZIP antes de executar. Faltam adb.exe ou FreeMyTV.apk.'
    }
    $expected = 'e7c9c39e2506c805e93c0c383d66f8543f8b8bb6bae9269551ddee4e341ead6d'
    if ((Get-FileHash -LiteralPath $apk -Algorithm SHA256).Hash -ne $expected) {
        throw 'O APK nao corresponde ao ficheiro verificado. A instalacao foi cancelada.'
    }
    Write-Host 'A TV e este PC devem estar no mesmo Wi-Fi, com depuracao ADB pela rede ativa na TV.'
    Write-Host 'O programa instala uma aplicacao. Nao substitui o Android nem atualiza o firmware.'
    $ip = Read-Host 'IP da TV (Enter para usar 192.168.1.253)'
    if ([string]::IsNullOrWhiteSpace($ip)) { $ip = '192.168.1.253' }
    $parsed = $null
    if (-not [System.Net.IPAddress]::TryParse($ip.Trim(), [ref]$parsed) -or -not (Test-PrivateIPv4 $parsed)) {
        throw 'Introduza apenas um endereco IPv4 privado da TV, sem porta ou outros caracteres.'
    }
    $serial = $parsed.ToString() + ':5555'
    & $adb connect $serial
    if ($LASTEXITCODE -ne 0) {
        throw 'Nao foi possivel ligar. Confira o IP e a depuracao pela rede. Se a TV pedir autorizacao, aceite e tente outra vez.'
    }
    $state = (& $adb -s $serial get-state 2>&1 | Out-String).Trim()
    if ($LASTEXITCODE -ne 0 -or $state -ne 'device') {
        throw 'A TV nao esta autorizada. Aceite o pedido de depuracao na TV e execute novamente.'
    }
    $sdkText = (& $adb -s $serial shell getprop ro.build.version.sdk 2>&1 | Out-String).Trim()
    $sdkExit = $LASTEXITCODE
    $sdk = 0
    if ($sdkExit -ne 0 -or -not [int]::TryParse($sdkText, [ref]$sdk) -or $sdk -lt 26) {
        throw 'Nao foi confirmado Android 8 ou posterior. Nenhuma instalacao foi feita.'
    }
    $maker = (& $adb -s $serial shell getprop ro.product.manufacturer | Out-String).Trim()
    $model = (& $adb -s $serial shell getprop ro.product.model | Out-String).Trim()
    Write-Host ("`nAparelho: {0} {1} | Android SDK {2} | {3}" -f $maker, $model, $sdk, $serial)
    $confirm = Read-Host 'Confirme que e a TV correta: escreva INSTALAR para instalar a aplicacao'
    if ($confirm -ne 'INSTALAR') { Write-Host 'Instalacao cancelada.'; return }
    & $adb -s $serial install -r $apk
    if ($LASTEXITCODE -ne 0) {
        throw 'A instalacao falhou. Copie a mensagem para o chat. Nao desinstale apps nem altere o sistema para contornar o erro.'
    }
    Write-Host "`nAplicacao instalada. Abra Free My TV na lista de apps da TV."
    Write-Host 'O ecra inicial nao foi trocado por este script. Veja as instrucoes no LEIA-ME.txt.'
}

try {
    if ($Acao -eq 'Procurar') { Find-LocalDevices } else { Install-FreeMyTV }
} catch {
    Write-Host ("`nErro: " + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
